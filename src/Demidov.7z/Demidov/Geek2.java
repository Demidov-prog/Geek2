package Demidov;

public class Geek2
{
    public static void main(String[] args){
        byte x = 1;
        short y = 2;
        int a = 23;
        long b = 145;
        float d = 2.32f;
        double c = 234.32;
        char v = 'm';
        boolean n = true;
    }
}
